package uk.bit1.spring_jpa.service.dto;

public record ProductDto(Long id, String name, String description) {
}
