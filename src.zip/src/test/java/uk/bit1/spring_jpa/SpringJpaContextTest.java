package uk.bit1.spring_jpa;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaContextTest {

//	@Test
//	void contextLoads() {
//	}

}
