package uk.bit1.spring_jpa.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import uk.bit1.spring_jpa.repository.projection.CustomerDetailView;
import uk.bit1.spring_jpa.repository.projection.CustomerWithOrderCountView;
import uk.bit1.spring_jpa.repository.projection.OrderWithProductCountView;

public interface CustomerQueryService {
    Page<CustomerWithOrderCountView> listCustomers(Pageable pageable);
    CustomerDetailView getCustomerDetails(long id);
    Page<OrderWithProductCountView> listOrdersForCustomer(long customerId, Pageable pageable);
}
